package com.yatik.qrscanner.di

import android.content.Context
import com.yatik.qrscanner.network.UrlPreviewApi
import com.yatik.qrscanner.network.food.FoodApi
import com.yatik.qrscanner.utils.connectivity.ConnectivityHelper
import com.yatik.qrscanner.utils.connectivity.DefaultConnectivityHelper
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

/*
 * Copyright 2023 Yatik
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Provides
    @Singleton
    fun provideRetrofitInstance(): Retrofit {
        val loggingInterceptor = HttpLoggingInterceptor()
        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY)
        val client = OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            .connectTimeout(5, TimeUnit.SECONDS)
            .build()
        return Retrofit.Builder()
            .baseUrl("https://world.openfoodfacts.org/")
            .addConverterFactory(GsonConverterFactory.create())
            .client(client)
            .build()
    }

    @Provides
    @Singleton
    fun provideUrlPreviewApi(
        retrofit: Retrofit
    ): UrlPreviewApi = retrofit.create(UrlPreviewApi::class.java)

    @Provides
    @Singleton
    fun provideFoodApi(
        retrofit: Retrofit
    ): FoodApi = retrofit.create(FoodApi::class.java)

    @Provides
    fun provideConnectivityHelper(
        @ApplicationContext appContext: Context
    ): ConnectivityHelper = DefaultConnectivityHelper(appContext)

}